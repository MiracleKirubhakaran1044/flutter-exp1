import 'package:flutter/material.dart';

void main() {
  runApp(GoalTrackerApp());
}

class GoalTrackerApp extends StatelessWidget {
  const GoalTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Goal Tracker",
      home: Scaffold(
        appBar: AppBar(
          title: const Text("My Goal Tracker"),
          backgroundColor: Colors.teal,
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Today's Goals",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                "Track your daily progress below",
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
              const SizedBox(height: 20),

              // Row section - goal categories
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: const [
                  Column(
                    children: [
                      Icon(Icons.fitness_center, color: Colors.teal, size: 40),
                      SizedBox(height: 8),
                      Text("Workout"),
                    ],
                  ),
                  Column(
                    children: [
                      Icon(Icons.book, color: Colors.teal, size: 40),
                      SizedBox(height: 8),
                      Text("Study"),
                    ],
                  ),
                  Column(
                    children: [
                      Icon(Icons.water_drop, color: Colors.teal, size: 40),
                      SizedBox(height: 8),
                      Text("Hydrate"),
                    ],
                  ),
                ],
              ),

              const Divider(height: 40, thickness: 2),

              const Text(
                "Your Goals",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),

              // Simple list of goals (no shadow boxes)
              const Text("• Morning Workout – 30 mins exercise",
                  style: TextStyle(fontSize: 16)),
              const SizedBox(height: 8),
              const Text("• Read Book – 2 chapters today",
                  style: TextStyle(fontSize: 16)),
              const SizedBox(height: 8),
              const Text("• Drink Water – 8 glasses",
                  style: TextStyle(fontSize: 16)),
              const SizedBox(height: 8),
              const Text("• Project Work – Complete UI design",
                  style: TextStyle(fontSize: 16)),

              const SizedBox(height: 20),

              Center(
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                  child: const Text("Add New Goal"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
